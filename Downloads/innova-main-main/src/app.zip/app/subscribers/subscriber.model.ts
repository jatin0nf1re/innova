export interface Subscriber {
  name: string,
  phone: string,
  email: string
}
// time: string,
