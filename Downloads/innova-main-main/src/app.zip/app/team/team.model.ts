export interface Team {
  _id: string,
  name: string,
  designation: string
  imagePath: string,
  linkedin: string
  mailId: string,
  contact: string
}
