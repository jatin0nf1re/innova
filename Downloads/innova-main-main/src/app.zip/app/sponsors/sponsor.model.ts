export interface Sponsor {
  _id: string,
  sponsorName: string,
  imagePath: string,
  status: string,
  sponsorTitle: string,
  year: string,
  link: string
}
