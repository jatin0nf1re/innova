import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-start-loader',
  templateUrl: './start-loader.component.html',
  styleUrls: ['./start-loader.component.scss']
})
export class StartLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
