export class Position{
    left : number;
    top : number;
}